<?php
/**
 *
 * @category        modules
 * @package         news
 * @author          WebsiteBaker Project
 * @copyright       2004-2009, Ryan Djurovich
 * @copyright       2009-2011, Website Baker Org. e.V.
 * @link            http://www.websitebaker2.org/
 * @license         http://www.gnu.org/licenses/gpl.html
 * @platform        WebsiteBaker 2.8.x
 * @requirements    PHP 5.2.2 and higher
 * @version         $Id: DE.php 1458 2011-06-26 14:13:05Z Luisehahne $
 * @filesource        $HeadURL: svn://isteam.dynxs.de/wb_svn/wb280/tags/2.8.3/wb/modules/news/languages/DE.php $
 * @lastmodified    $Date: 2011-06-26 16:13:05 +0200 (So, 26. Jun 2011) $
 *
 */

//Modul Description
$module_description = 'Mit diesem Modul k&ouml;nnen sie eine News Seite ihrer Seite hinzuf&uuml;gen.';

//Variables for the backend
$MOD_NEWS['SETTINGS'] = 'News Einstellungen';

//Variables for the frontend
$MOD_NEWS['TEXT_READ_MORE'] = 'Weiterlesen';
$MOD_NEWS['TEXT_POSTED_BY'] = 'Ver&ouml;ffentlicht von';
$MOD_NEWS['TEXT_ON'] = 'am';
$MOD_NEWS['TEXT_LAST_CHANGED'] = 'Zuletzt ge&auml;ndert am';
$MOD_NEWS['TEXT_AT'] = 'um';
$MOD_NEWS['TEXT_BACK'] = 'Zur&uuml;ck zur Übersicht';
$MOD_NEWS['TEXT_COMMENTS'] = 'Kommentare';
$MOD_NEWS['TEXT_COMMENT'] = 'Kommentar';
$MOD_NEWS['TEXT_ADD_COMMENT'] = 'Kommentar hinzuf&uuml;gen';
$MOD_NEWS['TEXT_BY'] = 'von';
$MOD_NEWS['PAGE_NOT_FOUND'] = 'Seite nicht gefunden';
$MOD_NEWS['NO_COMMENT_FOUND'] = 'Kein Kommentar gefunden';

$TEXT['UNKNOWN'] = 'Gast';
