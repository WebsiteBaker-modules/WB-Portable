//:Emailfiltering on your output - dummy Droplet
//:usage:  [[EmailFilter]]
return '';