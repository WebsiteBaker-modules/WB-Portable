-- Status:23:196:MP_0:wbdemo:php:1.24.4:First backup incl. some demo pages:5.6.13:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|wb_addons|40|8624|2015-10-15 07:36:38|MyISAM
-- TABLE|wb_groups|1|2596|2013-10-25 09:31:42|MyISAM
-- TABLE|wb_mod_addon_file_editor|1|2068|2013-10-25 09:31:54|MyISAM
-- TABLE|wb_mod_captcha_control|2|1088|2013-10-25 09:32:08|MyISAM
-- TABLE|wb_mod_code|2|2128|2013-10-25 09:32:20|MyISAM
-- TABLE|wb_mod_droplets|16|20040|2015-10-14 18:15:34|MyISAM
-- TABLE|wb_mod_form_fields|5|2316|2015-10-14 18:37:51|MyISAM
-- TABLE|wb_mod_form_settings|2|2560|2015-10-14 18:37:51|MyISAM
-- TABLE|wb_mod_form_submissions|0|1024|2013-10-25 09:37:53|MyISAM
-- TABLE|wb_mod_jsadmin|3|2176|2013-10-25 09:38:06|MyISAM
-- TABLE|wb_mod_menu_link|1|2092|2013-10-25 09:38:17|MyISAM
-- TABLE|wb_mod_news_comments|1|2068|2013-10-25 09:38:33|MyISAM
-- TABLE|wb_mod_news_groups|0|1024|2015-10-15 07:36:38|MyISAM
-- TABLE|wb_mod_news_posts|6|5372|2015-10-15 07:36:38|MyISAM
-- TABLE|wb_mod_news_settings|3|5404|2013-10-25 09:39:13|MyISAM
-- TABLE|wb_mod_output_filter|5|8312|2015-10-15 07:26:09|MyISAM
-- TABLE|wb_mod_wrapper|1|2096|2013-10-25 09:39:58|MyISAM
-- TABLE|wb_mod_wysiwyg|3|4636|2013-10-25 09:40:10|MyISAM
-- TABLE|wb_pages|6|2596|2015-10-14 18:37:51|MyISAM
-- TABLE|wb_search|31|6764|2013-10-31 10:49:22|MyISAM
-- TABLE|wb_sections|7|2260|2013-10-25 09:40:42|MyISAM
-- TABLE|wb_settings|59|4048|2015-10-15 07:36:38|MyISAM
-- TABLE|wb_users|1|2164|2015-10-15 07:36:38|MyISAM
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2015-10-15 07:36

--
-- Create Table `wb_addons`
--

DROP TABLE IF EXISTS `wb_addons`;
CREATE TABLE `wb_addons` (
  `addon_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `directory` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `function` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `platform` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `author` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `license` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`addon_id`)
) ENGINE=MyISAM AUTO_INCREMENT=206 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_addons`
--

/*!40000 ALTER TABLE `wb_addons` DISABLE KEYS */;
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('201','language','PT','Portuguese (Brazil)','','','2.8','2.8.x','Daniel Neto','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('200','language','PL','Polski','','','2.8','2.8.x','Marek Stepien;','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('199','language','NO','Norsk','','','2.8','2.8.x','Odd Egil Hansen (oeh)','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('177','module','wrapper','Wrapper','This module allows you to wrap your site around another using an inline frame','page','2.8.3','2.7 | 2.8.x','Ryan Djurovich','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('176','module','show_menu2','show_menu2','A code snippet for the Website Baker CMS providing a complete replacement for the builtin menu functions. See <a href=\"http://code.jellycan.com/show_menu2/\" target=\"_blank\">http://code.jellycan.com/show_menu2/</a> for details or view the <a href=\"http://127.0.0.1:4001/wbdemo/modules/show_menu2/README.en.txt\" target=\"_blank\">readme</a> file.','snippet','4.9.6','2.7 | 2.8.2','Brodie Thiesfield','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('175','module','SecureFormSwitcher','SecureForm Switcher','This module switch between the <strong>SingleTab SecureForm</strong> and <strong>MultiTab SecureForm</strong>.','tool','0.6.6','2.8.2','D. W&ouml;llbrrink (Luisehahne),  Florian Meerwinck (instantflorian), Michael Tentschert (test&ouml;r)','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('174','module','output_filter','Frontend Output Filter','This module allows to filter the output before displaying it on the frontend. Support for filtering mailto links and mail addresses in strings.','tool','0.9','2.8.3','Christian Sommer(doc), Dietmar WÃ¶llbrink(luisehahne), Manuela v.d. Decken(DarkViper)','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('173','module','news','News','This page type is designed for making a news page.','page','3.5.8','2.8.3','Ryan Djurovich, Rob Smith, Werner v.d.Decken','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('172','module','menu_link','Menu Link','This module allows you to insert a link into the menu.','page','2.8','2.8.x','Ryan Djurovich, thorn','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('171','module','jsadmin','Javascript Admin','This module adds Javascript functionality to the Website Baker Admin to improve some of the UI interactions. Uses the YahooUI library.','tool','1.4.0','2.7 | 2.8.x','Stepan Riha, Swen Uth','BSD License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('170','module','form','Form','This module allows you to create customised online forms, such as a feedback form. Thank-you to Rudolph Lartey who help enhance this module, providing code for extra field types, etc.','page','2.8.5','2.8.x','Ryan Djurovich & Rudolph Lartey - additions John Maats - PCWacht','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('198','language','NL','Nederlands','','','2.8','2.8.x','Bramus, CodeALot, Luckyluke, Argos','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('168','module','droplets','Droplets','This tool allows you to manage your local Droplets.','tool','1.2.0','2.8.x','Ruud and pcwacht','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('169','module','fckeditor','FCKeditor','This module allows you to edit the contents of a page using <a href=\"http://www.fckeditor.net/\" target=\"_blank\">FCKeditor v2.6.6</a>.','wysiwyg','2.9.7.1','2.7 | 2.8.x','Christian Sommer, P. Widlund, S. Braunewell, M. Gallas, Wouldlouper, Aldus, Luisehahne','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('197','language','LV','Latvie&scaron;u','','','2.8','2.8.x','Kri&scaron;janis Rijnieks','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('196','language','IT','Italiano','','','2.8','2.8.x','Roberto Rossi','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('195','language','HU','Magyar','','','2.8','2.8.x','Zsolt + Robert','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('194','language','HR','Hrvatski','','','2.8','2.8.x','Vedran Presecki','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('193','language','FR','Fran&ccedil;ais','','','2.8','2.8.x','Marin Susac','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('192','language','FI','Suomi','','','2.8','2.8.x','Jontse','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('191','language','ET','Eesti','','','2.8','2.8.x','Heiko H&auml;ng','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('190','language','ES','Spanish','','','2.8','2.8.x','Samuel Mateo, Jr. | samuelmateo.com','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('189','language','EN','English','','','2.8','2.8.x','Ryan Djurovich, Christian Sommer','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('188','language','DE','Deutsch','','','3.0','2.9','Stefan Braunewell, Matthias Gallas','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('187','language','DA','Dansk','','','2.8','2.8.x','Allan Christensen','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('186','language','CS','&#268;e&scaron;tina','','','2.8','2.8.x','WebStep, s.r.o.','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('167','module','code','Code','This module allows you to execute PHP commands (limit access to users you trust!!)','page','2.8.3','2.7 | 2.8.x','Ryan Djurovich','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('166','module','captcha_control','Captcha and Advanced-Spam-Protection (ASP) Control','Admin-Tool to control CAPTCHA and ASP','tool','1.2.0','2.7 | 2.8.x','Thomas Hornik (thorn)','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('185','language','CA','Catalan','','','2.8','2.8.x','Carles Escrig (simkin)','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('184','language','BG','Bulgarian','','','2.8','2.8.x','Hristo Benev(&#1061;&#1088;&#1080;&#1089;&#1090;&#1086; &#1041;&#1077;&#1085;&#1077;&#1074;)','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('183','template','wb_theme','WB Theme','Default backend theme for Website Baker 2.8.','theme','2.8.1','2.8.3','Johannes Tassilo Gruber','<a href=\"http://www.gnu.org/licenses/gpl.html\">GNU General Public License</a>');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('182','template','pinzsimple','PinzSimple (default)','Default template for WebsiteBaker.','template','0.90','2.8.3','pinzweb.at OG','In combination with any version of any kind of software which is produced and originaly published by the WebsiteBaker.org Project PinzSimple is available under the GNU General Public License.');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('179','template','allcss','All CSS','Default template for Website Baker. This template is designed with one goal in mind: to completely control layout with CSS. In case you were wondering, that is where the name came from.','template','2.71','2.7','Ryan Djurovich, C. Sommer','<a href=\"http://www.gnu.org/licenses/gpl.html\">GNU General Public License</a>');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('180','template','argos_theme','Argos Theme','Enhanced backend theme for Website Baker 2.8.','theme','1.7.0','2.8.3','Jurgen Nijhuis (Argos Media) & Ruud Eisinga','<a href=\"http://www.gnu.org/licenses/gpl.html\">GNU General Public License</a>');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('181','template','blank','Blank Template','This template is for use on page where you do not want anything wrapping the content.','template','2.70','2.7','Ryan Djurovich, C. Sommer','<a href=\"http://www.gnu.org/licenses/gpl.html\">GNU General Public License</a>');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('178','module','wysiwyg','WYSIWYG','This module allows you to edit the contents of a page using a graphical editor','page','2.9.0','2.8.2','Ryan Djurovich','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('202','language','RU','Russian','','','2.8','2.8.x','Kirill Karakulko (kirill@nadosoft.com)','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('203','language','SE','Svenska','','','2.8','2.8.x','Markus Eriksson, Peppe Bergqvist','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('204','language','SK','Slovensky','','','2.8','2.8.x','Michal Kurtulik - YONIX.SK','GNU General Public License');
INSERT INTO `wb_addons` (`addon_id`,`type`,`directory`,`name`,`description`,`function`,`version`,`platform`,`author`,`license`) VALUES ('205','language','TR','T&uuml;rk','','','2.8','2.8.x','Atakan KO&Ccedil;','GNU General Public License');
/*!40000 ALTER TABLE `wb_addons` ENABLE KEYS */;


--
-- Create Table `wb_groups`
--

DROP TABLE IF EXISTS `wb_groups`;
CREATE TABLE `wb_groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `system_permissions` text COLLATE utf8_unicode_ci NOT NULL,
  `module_permissions` text COLLATE utf8_unicode_ci NOT NULL,
  `template_permissions` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_groups`
--

/*!40000 ALTER TABLE `wb_groups` DISABLE KEYS */;
INSERT INTO `wb_groups` (`group_id`,`name`,`system_permissions`,`module_permissions`,`template_permissions`) VALUES ('1','Administrators','pages,pages_view,pages_add,pages_add_l0,pages_settings,pages_modify,pages_intro,pages_delete,media,media_view,media_upload,media_rename,media_delete,media_create,addons,modules,modules_view,modules_install,modules_uninstall,templates,templates_view,templates_install,templates_uninstall,languages,languages_view,languages_install,languages_uninstall,settings,settings_basic,settings_advanced,access,users,users_view,users_add,users_modify,users_delete,groups,groups_view,groups_add,groups_modify,groups_delete,admintools','','');
/*!40000 ALTER TABLE `wb_groups` ENABLE KEYS */;


--
-- Create Table `wb_mod_addon_file_editor`
--

DROP TABLE IF EXISTS `wb_mod_addon_file_editor`;
CREATE TABLE `wb_mod_addon_file_editor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ftp_enabled` int(1) NOT NULL,
  `ftp_server` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ftp_user` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ftp_password` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `ftp_port` int(11) NOT NULL,
  `ftp_start_dir` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_addon_file_editor`
--

/*!40000 ALTER TABLE `wb_mod_addon_file_editor` DISABLE KEYS */;
INSERT INTO `wb_mod_addon_file_editor` (`id`,`ftp_enabled`,`ftp_server`,`ftp_user`,`ftp_password`,`ftp_port`,`ftp_start_dir`) VALUES ('1','0','-','-','','21','/');
/*!40000 ALTER TABLE `wb_mod_addon_file_editor` ENABLE KEYS */;


--
-- Create Table `wb_mod_captcha_control`
--

DROP TABLE IF EXISTS `wb_mod_captcha_control`;
CREATE TABLE `wb_mod_captcha_control` (
  `enabled_captcha` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `enabled_asp` varchar(1) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `captcha_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'calc_text',
  `asp_session_min_age` int(11) NOT NULL DEFAULT '20',
  `asp_view_min_age` int(11) NOT NULL DEFAULT '10',
  `asp_input_min_age` int(11) NOT NULL DEFAULT '5',
  `ct_text` longtext COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_captcha_control`
--

/*!40000 ALTER TABLE `wb_mod_captcha_control` DISABLE KEYS */;
INSERT INTO `wb_mod_captcha_control` (`enabled_captcha`,`enabled_asp`,`captcha_type`,`asp_session_min_age`,`asp_view_min_age`,`asp_input_min_age`,`ct_text`) VALUES ('1','1','calc_text','20','10','5','');
INSERT INTO `wb_mod_captcha_control` (`enabled_captcha`,`enabled_asp`,`captcha_type`,`asp_session_min_age`,`asp_view_min_age`,`asp_input_min_age`,`ct_text`) VALUES ('1','1','calc_text','20','10','5','');
/*!40000 ALTER TABLE `wb_mod_captcha_control` ENABLE KEYS */;


--
-- Create Table `wb_mod_code`
--

DROP TABLE IF EXISTS `wb_mod_code`;
CREATE TABLE `wb_mod_code` (
  `section_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_code`
--

/*!40000 ALTER TABLE `wb_mod_code` DISABLE KEYS */;
INSERT INTO `wb_mod_code` (`section_id`,`page_id`,`content`) VALUES ('0','0','');
INSERT INTO `wb_mod_code` (`section_id`,`page_id`,`content`) VALUES ('5','5','echo \'this is a code page for php snippets\';');
/*!40000 ALTER TABLE `wb_mod_code` ENABLE KEYS */;


--
-- Create Table `wb_mod_droplets`
--

DROP TABLE IF EXISTS `wb_mod_droplets`;
CREATE TABLE `wb_mod_droplets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `code` longtext COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `modified_when` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  `admin_edit` int(11) NOT NULL DEFAULT '0',
  `admin_view` int(11) NOT NULL DEFAULT '0',
  `show_wysiwyg` int(11) NOT NULL DEFAULT '0',
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_droplets`
--

/*!40000 ALTER TABLE `wb_mod_droplets` DISABLE KEYS */;
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('1','EmailFilter','return \'\';','Emailfiltering on your output - dummy Droplet','1444839333','1','1','0','0','0','usage:  [[EmailFilter]]');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('2','LoginBox','//:Absolute or relative url possible\n//:Remember to enable frontend login in your website settings.\n\n	global $wb,$page_id,$TEXT, $MENU, $HEADING;\n\n	$return_value = \'<div class=\"login-box\">\'.\"\\n\";\n	$return_admin = \' \';\n	// Return a system permission\n	function get_permission($name, $type = \'system\')\n	{\n	   	global $wb;\n	// Append to permission type\n		$type .= \'_permissions\';\n		// Check if we have a section to check for\n		if($name == \'start\') {\n			return true;\n		} else {\n			// Set system permissions var\n			$system_permissions = $wb->get_session(\'SYSTEM_PERMISSIONS\');\n			// Set module permissions var\n			$module_permissions = $wb->get_session(\'MODULE_PERMISSIONS\');\n			// Set template permissions var\n			$template_permissions = $wb->get_session(\'TEMPLATE_PERMISSIONS\');\n			// Return true if system perm = 1\n			if (isset($$type) && is_array($$type) && is_numeric(array_search($name, $$type))) {\n				if($type == \'system_permissions\') {\n					return true;\n				} else {\n					return false;\n				}\n			} else {\n				if($type == \'system_permissions\') {\n					return false;\n				} else {\n					return true;\n				}\n			}\n		}\n	}\n\n	function get_page_permission($page, $action=\'admin\') {\n		if ($action!=\'viewing\'){ $action=\'admin\';}\n		$action_groups=$action.\'_groups\';\n		$action_users=$action.\'_users\';\n		if (is_array($page)) {\n				$groups=$page[$action_groups];\n				$users=$page[$action_users];\n		} else {\n			global $database,$wb;\n			$results = $database->query(\"SELECT $action_groups,$action_users FROM \".TABLE_PREFIX.\"pages WHERE page_id = \'$page\'\");\n			$result = $results->fetchRow();\n			$groups = explode(\',\', str_replace(\'_\', \'\', $result[$action_groups]));\n			$users = explode(\',\', str_replace(\'_\', \'\', $result[$action_users]));\n		}\n\n		$in_group = FALSE;\n		foreach($wb->get_groups_id() as $cur_gid){\n		    if (in_array($cur_gid, $groups)) {\n		        $in_group = TRUE;\n		    }\n		}\n		if((!$in_group) AND !is_numeric(array_search($wb->get_user_id(), $users))) {\n			return false;\n		}\n		return true;\n	}\n\n// Get redirect\n	$redirect_url = ((isset($_SESSION[\'HTTP_REFERER\']) && $_SESSION[\'HTTP_REFERER\'] != \'\') ? $_SESSION[\'HTTP_REFERER\'] : WB_URL );\n   	$redirect_url = (isset($redirect) && ($redirect!=\'\') ? $redirect : $redirect_url);\n\n	if ( ( FRONTEND_LOGIN == \'enabled\') &&\n		    ( VISIBILITY != \'private\') &&\n		        ( $wb->get_session(\'USER_ID\') == \'\')  )\n	{\n		$return_value .= \'<form action=\"\'.LOGIN_URL.\'\" method=\"post\">\'.\"\\n\";\n		$return_value .= \'<input type=\"hidden\" name=\"url\" value=\"\'.$redirect_url.\'\" />\'.\"\\n\";\n    	$return_value .= \'<fieldset>\'.\"\\n\";\n		$return_value .= \'<h1>\'.$TEXT[\'LOGIN\'].\'</h1>\'.\"\\n\";\n		$return_value .= \'<label for=\"username\">\'.$TEXT[\'USERNAME\'].\':</label>\'.\"\\n\";\n		$return_value .= \'<p><input type=\"text\" name=\"username\" id=\"username\"  /></p>\'.\"\\n\";\n		$return_value .= \'<label for=\"password\">\'.$TEXT[\'PASSWORD\'].\':</label>\'.\"\\n\";\n		$return_value .= \'<p><input type=\"password\" name=\"password\" id=\"password\"/></p>\'.\"\\n\";\n		$return_value .= \'<p><input type=\"submit\" id=\"submit\" value=\"\'.$TEXT[\'LOGIN\'].\'\" class=\"dbutton\" /></p>\'.\"\\n\";\n    	$return_value .= \'<ul class=\"login-advance\">\'.\"\\n\";\n		$return_value .= \'<li class=\"forgot\"><a href=\"\'.FORGOT_URL.\'\"><span>\'.$TEXT[\'FORGOT_DETAILS\'].\'</span></a></li>\'.\"\\n\";\n\n		if (intval(FRONTEND_SIGNUP) > 0)\n	    {\n	        $return_value .= \'<li class=\"sign\"><a href=\"\'.SIGNUP_URL.\'\">\'.$TEXT[\'SIGNUP\'].\'</a></li>\'.\"\\n\";\n	    }\n	    $return_value .= \'</ul>\'.\"\\n\";\n	    $return_value .= \'</fieldset>\'.\"\\n\";\n		$return_value .= \'</form>\'.\"\\n\";\n\n	} elseif( (FRONTEND_LOGIN == \'enabled\') &&\n				(is_numeric($wb->get_session(\'USER_ID\'))) )\n	{\n			$return_value .= \'<form action=\"\'.LOGOUT_URL.\'\" method=\"post\" class=\"login-table\">\'.\"\\n\";\n        	$return_value .= \'<fieldset>\'.\"\\n\";\n			$return_value .= \'<h1>\'.$TEXT[\"LOGGED_IN\"].\'</h1>\'.\"\\n\";\n			$return_value .= \'<label>\'.$TEXT[\'WELCOME_BACK\'].\', \'.$wb->get_display_name().\'</label>\'.\"\\n\";\n			$return_value .= \'<p><input type=\"submit\" name=\"submit\" value=\"\'.$MENU[\'LOGOUT\'].\'\" class=\"dbutton\" /></p>\'.\"\\n\";\n	        $return_value .= \'<ul class=\"logout-advance\">\'.\"\\n\";\n			$return_value .= \'<li class=\"preference\"><a href=\"\'.PREFERENCES_URL.\'\" title=\"\'.$MENU[\'PREFERENCES\'].\'\">\'.$MENU[\'PREFERENCES\'].\'</a></li>\'.\"\\n\";\n\n			if ($wb->ami_group_member(\'1\'))  //change ot the group that should get special links\n	        {\n		        $return_admin .= \'<li class=\"admin\"><a target=\"_blank\" href=\"\'.ADMIN_URL.\'/index.php\" title=\"\'.$TEXT[\'ADMINISTRATION\'].\'\" class=\"blank_target\">\'.$TEXT[\"ADMINISTRATION\"].\'</a></li>\'.\"\\n\";\n				//you can add more links for your users like userpage, lastchangedpages or something\n				$return_value .= $return_admin;\n			}\n            //change ot the group that should get special links\n			if( get_permission(\'pages_modify\') && get_page_permission( PAGE_ID ) )\n	        {\n				$return_value .= \'<li class=\"modify\"><a target=\"_blank\" href=\"\'.ADMIN_URL.\'/pages/modify.php?page_id=\'.PAGE_ID.\'\" title=\"\'.$HEADING[\'MODIFY_PAGE\'].\'\" class=\"blank_target\">\'.$HEADING[\'MODIFY_PAGE\'].\'</a></li>\'.\"\\n\";\n	        }\n	        $return_value .= \'</ul>\'.\"\\n\";\n	        $return_value .= \'</fieldset>\'.\"\\n\";\n			$return_value .= \'</form>\'.\"\\n\";\n	}\n	$return_value .= \'</div>\'.\"\\n\";\n	return $return_value;\n','Puts a Login / Logout box on your page.','1444839333','1','1','0','0','0','Use: [[LoginBox?redirect=url]]');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('3','Lorem','$lorem = array();\n$lorem[] = \"Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Ut odio. Nam sed est. Nam a risus et est iaculis adipiscing. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Integer ut justo. In tincidunt viverra nisl. Donec dictum malesuada magna. Curabitur id nibh auctor tellus adipiscing pharetra. Fusce vel justo non orci semper feugiat. Cras eu leo at purus ultrices tristique.<br /><br />\";\n$lorem[] = \"Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.<br /><br />\";\n$lorem[] = \"Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.<br /><br />\";\n$lorem[] = \"Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.<br /><br />\";\n$lorem[] = \"Cras consequat magna ac tellus. Duis sed metus sit amet nunc faucibus blandit. Fusce tempus cursus urna. Sed bibendum, dolor et volutpat nonummy, wisi justo convallis neque, eu feugiat leo ligula nec quam. Nulla in mi. Integer ac mauris vel ligula laoreet tristique. Nunc eget tortor in diam rhoncus vehicula. Nulla quis mi. Fusce porta fringilla mauris. Vestibulum sed dolor. Aliquam tincidunt interdum arcu. Vestibulum eget lacus. Curabitur pellentesque egestas lectus. Duis dolor. Aliquam erat volutpat. Aliquam erat volutpat. Duis egestas rhoncus dui. Sed iaculis, metus et mollis tincidunt, mauris dolor ornare odio, in cursus justo felis sit amet arcu. Aenean sollicitudin. Duis lectus leo, eleifend mollis, consequat ut, venenatis at, ante.<br /><br />\";\n$lorem[] = \"Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<br /><br />\"; \nif (!isset($blocks)) $blocks=1;\n$blocks = (int)$blocks - 1;\nif ($blocks <= 0) $blocks = 0;\nif ($blocks > 5) $blocks = 5;\n$returnvalue = \"\";\nfor ( $i=0 ; $i<=$blocks ; $i++) {\n    $returnvalue .= $lorem[$i];\n}\nreturn $returnvalue;','Create Lorum Ipsum text','1444839333','1','1','0','0','0','Use: [[Lorem?blocks=6]] (max 6 paragraphs)');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('4','ModifiedWhen','global $database, $wb;\rif (PAGE_ID>0) {\r	$query=$database->query(\"SELECT modified_when FROM \".TABLE_PREFIX.\"pages where page_id=\".PAGE_ID);\r	$mod_details=$query->fetchRow();\r	return \"This page was last modified on \".date(\"d/m/Y\",$mod_details[0]). \" at \".date(\"H:i\",$mod_details[0]).\".\";\r}','Displays the last modification time of the current page','1444839333','1','1','0','0','0','Use [[ModifiedWhen]]');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('5','NextPage','$info = show_menu2(0, SM2_CURR, SM2_START, SM2_ALL|SM2_BUFFER, \'[if(class==menu-current){[level] [sib] [sibCount] [parent]}]\', \'\', \'\', \'\');\rlist($nLevel, $nSib, $nSibCount, $nParent) = explode(\' \', $info);\r\r// show next\r$nxt = $nSib < $nSibCount ? $nSib + 1 : 0;\rif ($nxt > 0) {\rreturn show_menu2(0, SM2_CURR, SM2_START, SM2_ALL|SM2_BUFFER,	\"[if(sib==$nxt){&gt;&gt; [a][menu_title]</a>}]\", \'\', \'\', \'\');\r}\relse return \'(no next)\';\r','Create a next link to your page','1444839333','1','1','0','0','0','Display a link to the next page on the same menu level');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('6','Oneliner','$line = file (dirname(__FILE__).\"/example/oneliners.txt\");\rshuffle($line);\rreturn $line[0]; \r','Create a random oneliner on your page','1444839333','1','1','0','0','0','Use: [[OneLiner]]. The file with the oneliner data is located in /modules/droplets/example/oneliners.txt');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('7','ParentPage','$info = show_menu2(0, SM2_CURR, SM2_START, SM2_ALL|SM2_BUFFER, \'[if(class==menu-current){[level] [sib] [sibCount] [parent]}]\', \'\', \'\', \'\');\rlist($nLevel, $nSib, $nSibCount, $nParent) = explode(\' \', $info);\r\r// show up level\rif ($nLevel > 0) {\r$lev = $nLevel - 1;\rreturn show_menu2(0, SM2_ROOT, SM2_CURR, SM2_CRUMB|SM2_BUFFER, \"[if(level==$lev){[a][menu_title]</a>}]\", \'\', \'\', \'\');\r}\relse \rreturn \'(no parent)\';\r\r','Create a parent link to your page','1444839333','1','1','0','0','0','Display a link to the parent page of the current page');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('8','PreviousPage','$info = show_menu2(0, SM2_CURR, SM2_START, SM2_ALL|SM2_BUFFER, \'[if(class==menu-current){[level] [sib] [sibCount] [parent]}]\', \'\', \'\', \'\');\rlist($nLevel, $nSib, $nSibCount, $nParent) = explode(\' \', $info);\r\r// show previous\r$prv = $nSib > 1 ? $nSib - 1 : 0;\rif ($prv > 0) { \rreturn show_menu2(0, SM2_CURR, SM2_START, SM2_ALL|SM2_BUFFER, \"[if(sib==$prv){[a][menu_title]</a> &lt;&lt;}]\", \'\', \'\', \'\');\r}\relse \rreturn \'(no previous)\';\r\r','Create a previous link to your page','1444839333','1','1','0','0','0','Display a link to the previous page on the same menu level');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('9','RandomImage','$dir = ( (isset($dir) && ($dir!=\'\') ) ? $dir : \'\'); \n$folder=opendir(WB_PATH.MEDIA_DIRECTORY.\'/\'.$dir.\'/.\'); \n$names = array();\nwhile ($file = readdir($folder))  {\n    $ext=strtolower(substr($file,-4));\n    if ($ext==\".jpg\"||$ext==\".gif\"||$ext==\".png\"){\n        $names[count($names)] = $file; \n    }\n}\nclosedir($folder);\nshuffle($names);\n$image=$names[0]; \n$name=substr($image,0,-4);\nreturn \'<img src=\"\'.WB_URL.MEDIA_DIRECTORY.\'/\'.$dir.\'/\'.$image.\'\" alt=\"\'.$name.\'\" width=\"95%\" />\';\n','Get a random image from a folder in the MEDIA folder.','1444839333','1','1','0','0','0','Commandline to use: [[RandomImage?dir=subfolder_in_mediafolder]]');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('10','SearchBox','global $TEXT;\n$return_value = true;\nif (!isset($msg)) $msg=\'search this site..\';\n$j = \"onfocus=\\\"if(this.value==\'$msg\'){this.value=\'\';this.style.color=\'#000\';}else{this.select();}\\\"\n        onblur=\\\"if(this.value==\'\'){this.value=\'$msg\';this.style.color=\'#b3b3b3\';}\\\"\";\nif(SHOW_SEARCH) { \n	$return_value  = \'<div class=\"searchbox\">\';\n	$return_value  .= \'<form action=\"\'.WB_URL.\'/search/index\'.PAGE_EXTENSION.\'\" method=\"get\" name=\"search\" class=\"searchform\" id=\"search\">\';\n	$return_value  .= \'<input style=\"color:#b3b3b3;\" type=\"text\" name=\"string\" size=\"25\" class=\"textbox\" value=\"\'.$msg.\'\" \'.$j.\'  />&nbsp;\';\n	$return_value  .= \'</form>\';\n	$return_value  .= \'</div>\';\n}\nreturn $return_value;\n','Create a searchbox','1444839333','1','1','0','0','0','Creates a serachbox on the position of [[searchbox]]. Optional parameter \"?msg=the search message\"');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('11','SectionPicker','global $database, $wb, $TEXT, $DGTEXT,$section_id,$page_id;\n$content = \'\';\n$sid = isset($sid) ? intval($sid) : 0;\nif( $sid ) {\n    $oldSid = $section_id; // save old sectionID\n    $sql  = \'SELECT `module` FROM `\'.TABLE_PREFIX.\'sections` \';\n    $sql .= \'WHERE `section_id`=\'.$sid;\n    if (($module = $database->get_one($sql))) {\n        if (is_readable(WB_PATH.\'/modules/\'.$module.\'/view.php\')) {\n            $_sFrontendCss = \'/modules/\'.$module.\'/frontend.css\';\n            if(is_readable(WB_PATH.$_sFrontendCss)) {\n                $_sSearch = preg_quote(WB_URL.\'/modules/\'.$module.\'/frontend.css\', \'/\');\n                if(preg_match(\'/<link[^>]*?href\\s*=\\s*\\\"\'.$_sSearch.\'\\\".*?\\/>/si\', $wb_page_data)) {\n                    $_sFrontendCss = \'\';\n                }else {\n                    $_sFrontendCss = \'<link href=\"\'.WB_URL.$_sFrontendCss.\'\" rel=\"stylesheet\" type=\"text/css\" media=\"screen\" />\';\n                }\n            } else { $_sFrontendCss = \'\'; }\n            $section_id = $sid;\n            ob_start();\n            require(WB_PATH.\'/modules/\'.$module.\'/view.php\');\n            $content = $_sFrontendCss.ob_get_clean();\n            $section_id = $oldSid; // restore old sectionID\n        }\n    }\n}\nreturn $content;','Load the view.php from any other section-module','1444839333','1','1','0','0','0','Use [[SectionPicker?sid=123]]');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('12','ShowRandomWysiwyg','global $database;\r\n	$content = \'\';\r\n	if (isset($section)) {\r\n		if( preg_match(\'/^[0-9]+(?:\\s*[\\,\\|\\-\\;\\:\\+\\#\\/]\\s*[0-9]+\\s*)*$/\', $section)) {\r\n			if (is_readable(WB_PATH.\'/modules/wysiwyg/view.php\')) {\r\n			// if valid arguments given and module wysiwyg is installed\r\n				// split and sanitize arguments\r\n				$aSections = preg_split(\'/[\\s\\,\\|\\-\\;\\:\\+\\#\\/]+/\', $section);\r\n				$section_id = $aSections[array_rand($aSections)]; // get random element\r\n				ob_start(); // generate output by wysiwyg module\r\n				require(WB_PATH.\'/modules/wysiwyg/view.php\');\r\n				$content = ob_get_clean();\r\n			}\r\n		}\r\n	}\r\nreturn $content;','Randomly display one WYSIWYG section from a given list','1444839333','1','1','0','0','0','Use [[ShowRandomWysiwyg?section=10,12,15,20]] possible Delimiters: [ ,;:|-+#/ ]');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('13','ShowWysiwyg','global $database, $section_id, $module;\r\n    $content = \'\';\r\n    $section = isset($section) ? intval($section) : 0;\r\n    if ($section) {\r\n        if (is_readable(WB_PATH.\'/modules/wysiwyg/view.php\')) {\r\n        // if valid section is given and module wysiwyg is installed\r\n            $iOldSectionId = intval($section_id); // save old SectionID\r\n            $section_id = $section;\r\n            ob_start(); // generate output by regulary wysiwyg module\r\n            require(WB_PATH.\'/modules/wysiwyg/view.php\');\r\n            $content = ob_get_clean();\r\n            $section_id = $iOldSectionId; // restore old SectionId\r\n        }\r\n    }\r\nreturn $content;','Display one defined WYSIWYG section','1444839333','1','1','0','0','0','Use [[ShowWysiwyg?section=10]]');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('14','SiteModified','global $database, $wb;\rif (PAGE_ID>0) {\r	$query=$database->query(\"SELECT max(modified_when) FROM \".TABLE_PREFIX.\"pages\");\r	$mod_details=$query->fetchRow();\r	return \"This site was last modified on \".date(\"d/m/Y\",$mod_details[0]). \" at \".date(\"H:i\",$mod_details[0]).\".\";\r}','Create information on when your site was last updated.','1444839333','1','1','0','0','0','Create information on when your site was last updated. Any page update counts.');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('15','Skype','$content=\'<div class=\"popup\">Check skypename!</div>\';\n$user = (isset($user) && ($user!=\'\') ? $user : \'\');\nif($user==\'\') { return $content; }\nreturn \'<div class=\"popup\"><img src=\"http://mystatus.skype.com/\'.$user.\'.png?t=\'.time().\'\" alt=\"My Skype status\" /></div>\';\n','Your skype status as an image','1444839333','1','1','0','0','0','Commandline to use: [[skype?user=skypename]]');
INSERT INTO `wb_mod_droplets` (`id`,`name`,`code`,`description`,`modified_when`,`modified_by`,`active`,`admin_edit`,`admin_view`,`show_wysiwyg`,`comments`) VALUES ('16','Text2Image','//clean up old files..\r\n$dir = WB_PATH.\'/temp/\';\r\n$dp = opendir($dir) or die (\'Could not open \'.$dir);\r\nwhile ($file = readdir($dp)) {\r\n	if ((preg_match(\'/img_/\',$file)) && (filemtime($dir.$file)) <  (strtotime(\'-10 minutes\'))) {\r\n		unlink($dir.$file);\r\n	}\r\n}\r\nclosedir($dp);\r\n\r\n$imgfilename = \'img_\'.rand().\'_\'.time().\'.jpg\';\r\n//create image\r\n$padding = 0;\r\n$font = 3;  	\r\n\r\n$height = imagefontheight($font) + ($padding * 2);\r\n$width = imagefontwidth($font) * strlen($text) + ($padding * 2);\r\n$image_handle = imagecreatetruecolor($width, $height);\r\n$text_color = imagecolorallocate($image_handle, 0, 0, 0);\r\n$background_color = imagecolorallocate($image_handle, 255, 255, 255);\r\n$bg_height = imagesy($image_handle);\r\n$bg_width = imagesx($image_handle);\r\nimagefilledrectangle($image_handle, 0, 0, $bg_width, $bg_height, $background_color);\r\nimagestring($image_handle, $font, $padding, $padding, $text, $text_color);\r\nimagejpeg($image_handle,WB_PATH.\'/temp/\'.$imgfilename,100);\r\nimagedestroy($image_handle);\r\n\r\nreturn \'<img src=\"\'.WB_URL.\'/temp/\'.$imgfilename.\'\" style=\"border:0px;margin:0px;padding:0px;vertical-align:middle;\" />\';','Create an image from the textparameter','1444839333','1','1','0','0','0','Use [[text2image?text=The text to create]]');
/*!40000 ALTER TABLE `wb_mod_droplets` ENABLE KEYS */;


--
-- Create Table `wb_mod_form_fields`
--

DROP TABLE IF EXISTS `wb_mod_form_fields`;
CREATE TABLE `wb_mod_form_fields` (
  `field_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `required` int(11) NOT NULL DEFAULT '0',
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `extra` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`field_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_form_fields`
--

/*!40000 ALTER TABLE `wb_mod_form_fields` DISABLE KEYS */;
INSERT INTO `wb_mod_form_fields` (`field_id`,`section_id`,`page_id`,`position`,`title`,`type`,`required`,`value`,`extra`) VALUES ('1','0','0','0','','','0','','');
INSERT INTO `wb_mod_form_fields` (`field_id`,`section_id`,`page_id`,`position`,`title`,`type`,`required`,`value`,`extra`) VALUES ('2','3','3','1','Contact us','heading','0','','<tr><td class=\"field_heading\" colspan=\"2\">{TITLE}{FIELD}</td></tr>');
INSERT INTO `wb_mod_form_fields` (`field_id`,`section_id`,`page_id`,`position`,`title`,`type`,`required`,`value`,`extra`) VALUES ('3','3','3','3','Subject','textfield','0','','');
INSERT INTO `wb_mod_form_fields` (`field_id`,`section_id`,`page_id`,`position`,`title`,`type`,`required`,`value`,`extra`) VALUES ('4','3','3','4','Message','textarea','0','','');
INSERT INTO `wb_mod_form_fields` (`field_id`,`section_id`,`page_id`,`position`,`title`,`type`,`required`,`value`,`extra`) VALUES ('6','3','3','2','Email','email','1','','');
/*!40000 ALTER TABLE `wb_mod_form_fields` ENABLE KEYS */;


--
-- Create Table `wb_mod_form_settings`
--

DROP TABLE IF EXISTS `wb_mod_form_settings`;
CREATE TABLE `wb_mod_form_settings` (
  `section_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `header` text COLLATE utf8_unicode_ci NOT NULL,
  `field_loop` text COLLATE utf8_unicode_ci NOT NULL,
  `footer` text COLLATE utf8_unicode_ci NOT NULL,
  `email_to` text COLLATE utf8_unicode_ci NOT NULL,
  `email_from` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email_fromname` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email_subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `success_page` text COLLATE utf8_unicode_ci NOT NULL,
  `success_email_to` text COLLATE utf8_unicode_ci NOT NULL,
  `success_email_from` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `success_email_fromname` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `success_email_text` text COLLATE utf8_unicode_ci NOT NULL,
  `success_email_subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `stored_submissions` int(11) NOT NULL DEFAULT '0',
  `max_submissions` int(11) NOT NULL DEFAULT '0',
  `use_captcha` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`section_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_form_settings`
--

/*!40000 ALTER TABLE `wb_mod_form_settings` DISABLE KEYS */;
INSERT INTO `wb_mod_form_settings` (`section_id`,`page_id`,`header`,`field_loop`,`footer`,`email_to`,`email_from`,`email_fromname`,`email_subject`,`success_page`,`success_email_to`,`success_email_from`,`success_email_fromname`,`success_email_text`,`success_email_subject`,`stored_submissions`,`max_submissions`,`use_captcha`) VALUES ('0','0','','','','','','','','','','','','','','0','0','0');
INSERT INTO `wb_mod_form_settings` (`section_id`,`page_id`,`header`,`field_loop`,`footer`,`email_to`,`email_from`,`email_fromname`,`email_subject`,`success_page`,`success_email_to`,`success_email_from`,`success_email_fromname`,`success_email_text`,`success_email_subject`,`stored_submissions`,`max_submissions`,`use_captcha`) VALUES ('3','3','<table cellpadding=\"2\" cellspacing=\"0\" border=\"0\" width=\"98%\">','<tr><td class=\"frm-field_title\">{TITLE}{REQUIRED}:</td><td>{FIELD}</td></tr>','<tr><td>Â </td>\r\n<td>\r\n<input type=\"submit\" name=\"submit\" value=\"Send\" />\r\n</td>\r\n</tr>\r\n</table>','admin@admin.com','admin@yourdomain.de','WB Mailer','Results from form on website...','none','','admin@yourdomain.de','WB Mailer','Thank you for submitting your form on Websitebaker Portable -Edition- 2.8.3','You have submitted a form','50','50','1');
/*!40000 ALTER TABLE `wb_mod_form_settings` ENABLE KEYS */;


--
-- Create Table `wb_mod_form_submissions`
--

DROP TABLE IF EXISTS `wb_mod_form_submissions`;
CREATE TABLE `wb_mod_form_submissions` (
  `submission_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `submitted_when` int(11) NOT NULL DEFAULT '0',
  `submitted_by` int(11) NOT NULL DEFAULT '0',
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`submission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_form_submissions`
--

/*!40000 ALTER TABLE `wb_mod_form_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `wb_mod_form_submissions` ENABLE KEYS */;


--
-- Create Table `wb_mod_jsadmin`
--

DROP TABLE IF EXISTS `wb_mod_jsadmin`;
CREATE TABLE `wb_mod_jsadmin` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `value` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_jsadmin`
--

/*!40000 ALTER TABLE `wb_mod_jsadmin` DISABLE KEYS */;
INSERT INTO `wb_mod_jsadmin` (`id`,`name`,`value`) VALUES ('1','mod_jsadmin_persist_order','1');
INSERT INTO `wb_mod_jsadmin` (`id`,`name`,`value`) VALUES ('2','mod_jsadmin_ajax_order_pages','1');
INSERT INTO `wb_mod_jsadmin` (`id`,`name`,`value`) VALUES ('3','mod_jsadmin_ajax_order_sections','1');
/*!40000 ALTER TABLE `wb_mod_jsadmin` ENABLE KEYS */;


--
-- Create Table `wb_mod_menu_link`
--

DROP TABLE IF EXISTS `wb_mod_menu_link`;
CREATE TABLE `wb_mod_menu_link` (
  `section_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `target_page_id` int(11) NOT NULL DEFAULT '0',
  `redirect_type` int(11) NOT NULL DEFAULT '302',
  `anchor` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `extern` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`section_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_menu_link`
--

/*!40000 ALTER TABLE `wb_mod_menu_link` DISABLE KEYS */;
INSERT INTO `wb_mod_menu_link` (`section_id`,`page_id`,`target_page_id`,`redirect_type`,`anchor`,`extern`) VALUES ('8','6','-1','302','0','http://www.google.com');
/*!40000 ALTER TABLE `wb_mod_menu_link` ENABLE KEYS */;


--
-- Create Table `wb_mod_news_comments`
--

DROP TABLE IF EXISTS `wb_mod_news_comments`;
CREATE TABLE `wb_mod_news_comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `post_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `commented_when` int(11) NOT NULL DEFAULT '0',
  `commented_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_news_comments`
--

/*!40000 ALTER TABLE `wb_mod_news_comments` DISABLE KEYS */;
INSERT INTO `wb_mod_news_comments` (`comment_id`,`section_id`,`page_id`,`post_id`,`title`,`comment`,`commented_when`,`commented_by`) VALUES ('1','0','0','0','','','0','0');
/*!40000 ALTER TABLE `wb_mod_news_comments` ENABLE KEYS */;


--
-- Create Table `wb_mod_news_groups`
--

DROP TABLE IF EXISTS `wb_mod_news_groups`;
CREATE TABLE `wb_mod_news_groups` (
  `group_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_news_groups`
--

/*!40000 ALTER TABLE `wb_mod_news_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `wb_mod_news_groups` ENABLE KEYS */;


--
-- Create Table `wb_mod_news_posts`
--

DROP TABLE IF EXISTS `wb_mod_news_posts`;
CREATE TABLE `wb_mod_news_posts` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `section_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `group_id` int(11) NOT NULL DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `link` text COLLATE utf8_unicode_ci NOT NULL,
  `content_short` text COLLATE utf8_unicode_ci NOT NULL,
  `content_long` text COLLATE utf8_unicode_ci NOT NULL,
  `commenting` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  `created_when` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `published_when` int(11) NOT NULL DEFAULT '0',
  `published_until` int(11) NOT NULL DEFAULT '0',
  `posted_when` int(11) NOT NULL DEFAULT '0',
  `posted_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`post_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_news_posts`
--

/*!40000 ALTER TABLE `wb_mod_news_posts` DISABLE KEYS */;
INSERT INTO `wb_mod_news_posts` (`post_id`,`section_id`,`page_id`,`group_id`,`active`,`position`,`title`,`link`,`content_short`,`content_long`,`commenting`,`created_when`,`created_by`,`published_when`,`published_until`,`posted_when`,`posted_by`) VALUES ('2','2','2','0','1','1','WebsiteBaker 2.8.1 - Portable -Edition- based on Server2Go','/posts/websitebaker-2.8.1---portable--edition--based-on-server2go-2','<p><a href=\"http://www.websitebaker-portable.com/\">WebsiteBaker Portable -Edition-</a> is based on the mobile Webserver <a href=\"http://www.server2go-web.de/\">Server2Go</a> from Timo Haberkern.</p>\r\n<p>This is the Release from the 2.8.1 Version of WebsiteBaker and the 1.7.3 Miniserver Package of Server2Go</p>','<h2>This is a Dropletexample Lorem Ipsum Droplet:</h2>\r\n<p>&nbsp;</p>\r\n<p>[[Lorem?blocks=3]]</p>','none','1265748060','1','1312490460','0','1329305602','1');
INSERT INTO `wb_mod_news_posts` (`post_id`,`section_id`,`page_id`,`group_id`,`active`,`position`,`title`,`link`,`content_short`,`content_long`,`commenting`,`created_when`,`created_by`,`published_when`,`published_until`,`posted_when`,`posted_by`) VALUES ('3','2','2','0','1','2','Features of Server2Go','/posts/features-of-server2go-3','<p>Short list of Features fo the used Webserver...</p>','<ul style=\"margin-top: 2px;\">\r\n    <li>Free! No royalties</li>\r\n    <li>Complete WAMPP Server-Stack</li>\r\n    <li>Runs directly from CD-ROM, USB Stick or Hard disk without installation</li>\r\n    <li>Full featured webserver (based on apache)</li>\r\n    <li>PHP 5.x support with many extensions installed (e.g. gd)</li>\r\n    <li>Supports SQLite databases</li>\r\n    <li>Runs on all versions of Windows from Win 98 and above, MAC OSX support is coming</li>\r\n    <li>Support for MySQL 5 Databases</li>\r\n    <li>Supports many PHP extensions (GD-Lib, PDO...) by default</li>\r\n    <li>Support for Perl 5.8</li>\r\n</ul>','none','1265748240','1','1312490640','0','1312568633','1');
INSERT INTO `wb_mod_news_posts` (`post_id`,`section_id`,`page_id`,`group_id`,`active`,`position`,`title`,`link`,`content_short`,`content_long`,`commenting`,`created_when`,`created_by`,`published_when`,`published_until`,`posted_when`,`posted_by`) VALUES ('4','2','2','0','1','3','Features of WebsiteBaker CMS','/posts/features-of-websitebaker-cms-4','<p>Short list of the Features of the easiest CMS in the web WebsiteBaker...</p>','<ul>\r\n    <li>Easy to use interface</li>\r\n    <li>WYSIWYG-editors in backend</li>\r\n    <li>Support of multiple languages</li>\r\n    <li>Management of files and media</li>\r\n    <li>Adjustable due to its template system</li>\r\n    <li>Infinite extensible because of add-ons</li>\r\n    <li>Group based Access Privilege System</li>\r\n</ul>\r\n<p>and much more....<img alt=\"\" src=\"http://127.0.0.1:4001/wbdemo/modules/fckeditor/fckeditor/editor/images/smiley/msn/shades_smile.gif\" /></p>','none','1265748300','1','1312490700','0','1329413173','1');
INSERT INTO `wb_mod_news_posts` (`post_id`,`section_id`,`page_id`,`group_id`,`active`,`position`,`title`,`link`,`content_short`,`content_long`,`commenting`,`created_when`,`created_by`,`published_when`,`published_until`,`posted_when`,`posted_by`) VALUES ('5','2','2','0','1','4','WebsiteBaker Portable -Edition- 2.8.3 ','/posts/websitebaker-portable--edition--2.8.3-5','<p><a href=\"http://www.websitebaker-portable.com/\">WebsiteBaker Portable -Edition-</a> is based on the mobile Webserver <a href=\"http://www.server2go-web.de/\">Server2Go</a> from Timo Haberkern.</p>\r\n<p>This is the Release from the 2.8.3 Version of WebsiteBaker and the 1.8.2 Package of Server2Go (with little changes).</p>','<h2>This is a Dropletexample Lorem Ipsum Droplet:</h2>\r\n<p>&nbsp;</p>\r\n<p>[[Lorem?blocks=3]]</p>','none','0','0','1329305220','0','1329328775','1');
INSERT INTO `wb_mod_news_posts` (`post_id`,`section_id`,`page_id`,`group_id`,`active`,`position`,`title`,`link`,`content_short`,`content_long`,`commenting`,`created_when`,`created_by`,`published_when`,`published_until`,`posted_when`,`posted_by`) VALUES ('6','2','2','0','1','5','WB 2.8.3 Rev.1638','/posts/wb-2.8.3-rev.1638-6','<p>The latest Hotfix Rev.1638 was included.<br />\r\nSome problems was fixed with this Hotfix.</p>','','none','0','0','1334989440','0','1382799074','1');
INSERT INTO `wb_mod_news_posts` (`post_id`,`section_id`,`page_id`,`group_id`,`active`,`position`,`title`,`link`,`content_short`,`content_long`,`commenting`,`created_when`,`created_by`,`published_when`,`published_until`,`posted_when`,`posted_by`) VALUES ('7','2','2','0','1','6','New Server-System','/posts/new-server-system-7','<p>The <strong>WAMP</strong>-Server-System (<strong>W</strong>indows, <strong>A</strong>pache, <strong>M</strong>ySQL, <strong>P</strong>HP) has changed.</p>\r\n<p>WB-Portable switched from Server2Go to USBWebserver v8.</p>','<h1>USBWebserver V8.6</h1>\r\n<p>&nbsp;</p>\r\n<ul>\r\n    <li>14 different languages</li>\r\n    <li>DPI bug fixed</li>\r\n    <li>Php 5.4.17</li>\r\n    <li>Httpd 2.4.6</li>\r\n    <li>PhpMyAdmin 4.0.4.2</li>\r\n    <li>MySQL 5.6.13</li>\r\n</ul>','none','0','0','1382799120','0','1382799965','1');
/*!40000 ALTER TABLE `wb_mod_news_posts` ENABLE KEYS */;


--
-- Create Table `wb_mod_news_settings`
--

DROP TABLE IF EXISTS `wb_mod_news_settings`;
CREATE TABLE `wb_mod_news_settings` (
  `section_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `header` text COLLATE utf8_unicode_ci NOT NULL,
  `post_loop` text COLLATE utf8_unicode_ci NOT NULL,
  `footer` text COLLATE utf8_unicode_ci NOT NULL,
  `posts_per_page` int(11) NOT NULL DEFAULT '0',
  `post_header` text COLLATE utf8_unicode_ci NOT NULL,
  `post_footer` text COLLATE utf8_unicode_ci NOT NULL,
  `comments_header` text COLLATE utf8_unicode_ci NOT NULL,
  `comments_loop` text COLLATE utf8_unicode_ci NOT NULL,
  `comments_footer` text COLLATE utf8_unicode_ci NOT NULL,
  `comments_page` text COLLATE utf8_unicode_ci NOT NULL,
  `commenting` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  `resize` int(11) NOT NULL DEFAULT '0',
  `use_captcha` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`section_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_news_settings`
--

/*!40000 ALTER TABLE `wb_mod_news_settings` DISABLE KEYS */;
INSERT INTO `wb_mod_news_settings` (`section_id`,`page_id`,`header`,`post_loop`,`footer`,`posts_per_page`,`post_header`,`post_footer`,`comments_header`,`comments_loop`,`comments_footer`,`comments_page`,`commenting`,`resize`,`use_captcha`) VALUES ('0','0','','','','0','','','','','','','','0','0');
INSERT INTO `wb_mod_news_settings` (`section_id`,`page_id`,`header`,`post_loop`,`footer`,`posts_per_page`,`post_header`,`post_footer`,`comments_header`,`comments_loop`,`comments_footer`,`comments_page`,`commenting`,`resize`,`use_captcha`) VALUES ('2','2','<table cellpadding=\"0\" cellspacing=\"0\" class=\"loop-header\">\r\n','<tr class=\"post-top\">\r\n<td class=\"post-title\"><a href=\"[LINK]\">[TITLE]</a></td>\r\n<td class=\"post-date\">[PUBLISHED_DATE], [PUBLISHED_TIME]</td>\r\n</tr>\r\n<tr>\r\n<td class=\"post-short\" colspan=\"2\">\r\n[SHORT]\r\n<span style=\"visibility:[SHOW_READ_MORE];\"><a href=\"[LINK]\">[TEXT_READ_MORE]</a></span><br /><br />\r\n</td>\r\n</tr>','</table>\r\n<table cellpadding=\"0\" cellspacing=\"0\" class=\"page-header\" style=\"display: [DISPLAY_PREVIOUS_NEXT_LINKS]\">\r\n<tr>\r\n<td class=\"page-left\">[PREVIOUS_PAGE_LINK]</td>\r\n<td class=\"page-center\">[OF]</td>\r\n<td class=\"page-right\">[NEXT_PAGE_LINK]</td>\r\n</tr>\r\n</table>','0','<table cellpadding=\"0\" cellspacing=\"0\" class=\"post-header\">\r\n<tr>\r\n<td><h1>[TITLE]</h1></td>\r\n<td rowspan=\"3\" style=\"display: [DISPLAY_IMAGE]\">[GROUP_IMAGE]</td>\r\n</tr>\r\n<tr>\r\n<td class=\"public-info\"><b>[TEXT_POSTED_BY] [DISPLAY_NAME] ([USERNAME]) [TEXT_ON] [PUBLISHED_DATE]</b></td>\r\n</tr>\r\n<tr style=\"display: [DISPLAY_GROUP]\">\r\n<td class=\"group-page\"><a href=\"[BACK]\">[PAGE_TITLE]</a> >> <a href=\"[BACK]?g=[GROUP_ID]\">[GROUP_TITLE]</a></td>\r\n</tr>\r\n</table>','<p>[TEXT_LAST_CHANGED]: [MODI_DATE] [TEXT_AT] [MODI_TIME]</p>\r\n<a href=\"[BACK]\">[TEXT_BACK]</a>','<br /><br />\r\n<h2>[TEXT_COMMENTS]</h2>\r\n<table cellpadding=\"2\" cellspacing=\"0\" class=\"comment-header\">','<tr>\r\n<td class=\"comment_title\">[TITLE]</td>\r\n<td class=\"comment_info\">[TEXT_BY] [DISPLAY_NAME] [TEXT_ON] [DATE] [TEXT_AT] [TIME]</td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\" class=\"comment-text\">[COMMENT]</td>\r\n</tr>','</table>\r\n<br /><a href=\"[ADD_COMMENT_URL]\">[TEXT_ADD_COMMENT]</a>','<h1>[TEXT_COMMENT]</h1>\r\n<h2>[POST_TITLE]</h2>\r\n<br />','none','0','1');
INSERT INTO `wb_mod_news_settings` (`section_id`,`page_id`,`header`,`post_loop`,`footer`,`posts_per_page`,`post_header`,`post_footer`,`comments_header`,`comments_loop`,`comments_footer`,`comments_page`,`commenting`,`resize`,`use_captcha`) VALUES ('6','2','<table cellpadding=\"0\" cellspacing=\"0\" class=\"loop-header\">\n','<tr class=\"post-top\">\r\n<td class=\"post-title\"><a href=\"[LINK]\">[TITLE]</a></td>\r\n<td class=\"post-date\">[PUBLISHED_DATE], [PUBLISHED_TIME]</td>\r\n</tr>\r\n<tr>\r\n<td class=\"post-short\" colspan=\"2\">\r\n[SHORT]\r\n<span style=\"visibility:[SHOW_READ_MORE];\"><a href=\"[LINK]\">[TEXT_READ_MORE]</a></span>\r\n</td>\r\n</tr>','</table>\r\n<table cellpadding=\"0\" cellspacing=\"0\" class=\"page-header\" style=\"display: [DISPLAY_PREVIOUS_NEXT_LINKS]\">\r\n<tr>\r\n<td class=\"page-left\">[PREVIOUS_PAGE_LINK]</td>\r\n<td class=\"page-center\">[OF]</td>\r\n<td class=\"page-right\">[NEXT_PAGE_LINK]</td>\r\n</tr>\r\n</table>','0','<table cellpadding=\"0\" cellspacing=\"0\" class=\"post-header\">\r\n<tr>\r\n<td><h1>[TITLE]</h1></td>\r\n<td rowspan=\"3\" style=\"display: [DISPLAY_IMAGE]\">[GROUP_IMAGE]</td>\r\n</tr>\r\n<tr>\r\n<td class=\"public-info\"><b>[TEXT_POSTED_BY] [DISPLAY_NAME] ([USERNAME]) [TEXT_ON] [PUBLISHED_DATE]</b></td>\r\n</tr>\r\n<tr style=\"display: [DISPLAY_GROUP]\">\r\n<td class=\"group-page\"><a href=\"[BACK]\">[PAGE_TITLE]</a> &gt;&gt; <a href=\"[BACK]?g=[GROUP_ID]\">[GROUP_TITLE]</a></td>\r\n</tr>\r\n</table>','<p>[TEXT_LAST_CHANGED]: [MODI_DATE] [TEXT_AT] [MODI_TIME]</p>\r\n<a href=\"[BACK]\">[TEXT_BACK]</a>','<br /><br />\r\n<h2>[TEXT_COMMENTS]</h2>\r\n<table cellpadding=\"2\" cellspacing=\"0\" class=\"comment-header\">','<tr>\r\n<td class=\"comment_title\">[TITLE]</td>\r\n<td class=\"comment_info\">[TEXT_BY] [DISPLAY_NAME] [TEXT_ON] [DATE] [TEXT_AT] [TIME]</td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\" class=\"comment-text\">[COMMENT]</td>\r\n</tr>','</table>\r\n<br /><a href=\"[ADD_COMMENT_URL]\">[TEXT_ADD_COMMENT]</a>','<h1>[TEXT_COMMENT]</h1>\r\n<h2>[POST_TITLE]</h2>\r\n<br />','none','0','1');
/*!40000 ALTER TABLE `wb_mod_news_settings` ENABLE KEYS */;


--
-- Create Table `wb_mod_output_filter`
--

DROP TABLE IF EXISTS `wb_mod_output_filter`;
CREATE TABLE `wb_mod_output_filter` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_output_filter`
--

/*!40000 ALTER TABLE `wb_mod_output_filter` DISABLE KEYS */;
INSERT INTO `wb_mod_output_filter` (`name`,`value`) VALUES ('sys_rel','0');
INSERT INTO `wb_mod_output_filter` (`name`,`value`) VALUES ('email_filter','1');
INSERT INTO `wb_mod_output_filter` (`name`,`value`) VALUES ('mailto_filter','1');
INSERT INTO `wb_mod_output_filter` (`name`,`value`) VALUES ('at_replacement','(at)');
INSERT INTO `wb_mod_output_filter` (`name`,`value`) VALUES ('dot_replacement','(dot)');
/*!40000 ALTER TABLE `wb_mod_output_filter` ENABLE KEYS */;


--
-- Create Table `wb_mod_wrapper`
--

DROP TABLE IF EXISTS `wb_mod_wrapper`;
CREATE TABLE `wb_mod_wrapper` (
  `section_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `url` text COLLATE utf8_unicode_ci NOT NULL,
  `height` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`section_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_wrapper`
--

/*!40000 ALTER TABLE `wb_mod_wrapper` DISABLE KEYS */;
INSERT INTO `wb_mod_wrapper` (`section_id`,`page_id`,`url`,`height`) VALUES ('4','4','http://www.websitebaker2.org','600');
/*!40000 ALTER TABLE `wb_mod_wrapper` ENABLE KEYS */;


--
-- Create Table `wb_mod_wysiwyg`
--

DROP TABLE IF EXISTS `wb_mod_wysiwyg`;
CREATE TABLE `wb_mod_wysiwyg` (
  `section_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `text` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_mod_wysiwyg`
--

/*!40000 ALTER TABLE `wb_mod_wysiwyg` DISABLE KEYS */;
INSERT INTO `wb_mod_wysiwyg` (`section_id`,`page_id`,`content`,`text`) VALUES ('7','2','<h1>NEWS</h1>','<h1>NEWS</h1>');
INSERT INTO `wb_mod_wysiwyg` (`section_id`,`page_id`,`content`,`text`) VALUES ('0','0','','');
INSERT INTO `wb_mod_wysiwyg` (`section_id`,`page_id`,`content`,`text`) VALUES ('1','1','<h1>H1 Header</h1>\r\n<p><span style=\"font-size: 14px;\">This is a WYSIWYG&nbsp;Page!&nbsp; (<strong>W</strong>hat <strong>Y</strong>ou <strong>S</strong>ee <strong>I</strong>s <strong>W</strong>hat <strong>Y</strong>ou <strong>G</strong>et)</span></p>\r\n<h2>H2 Header</h2>\r\n<h3>H3 Header</h3>\r\n<h4>H4 Header</h4>\r\n<h5>H5 Header</h5>\r\n<h6>H6 Header</h6>\r\n<ol>\r\n    <li>Numeric List</li>\r\n    <li>Numeric List</li>\r\n    <li>Numeric List</li>\r\n</ol>\r\n<ul>\r\n    <li>This is a normal List</li>\r\n    <li>This is a normal List</li>\r\n    <li>This is a normal List</li>\r\n</ul>\r\n<blockquote>\r\n<p>Blockquote for writing important notes in your content<br />\r\nand style it different...</p>\r\n<p>&nbsp;</p>\r\n</blockquote>\r\n<p>&nbsp;<img width=\"115\" align=\"left\" height=\"167\" src=\"{SYSVAR:MEDIA_REL}/wb_box.png\" alt=\"\" /></p>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: right;\"><u><em><strong>Text right side</strong></em></u><br />\r\n[[Lorem?blocks=1]]</p>\r\n<p style=\"text-align: center;\"><u><em><strong>Text center</strong></em></u></p>\r\n<p style=\"text-align: center;\">[[Lorem?blocks=1]]</p>\r\n<pre>\r\nFor other special notes in your content ...</pre>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: left;\"><u><em><strong>Text left side</strong></em></u><br />\r\n[[Lorem?blocks=4]]</p>','<h1>H1 Header</h1>\r\n<p><span style=\"font-size: 14px;\">This is a WYSIWYG&nbsp;Page!&nbsp; (<strong>W</strong>hat <strong>Y</strong>ou <strong>S</strong>ee <strong>I</strong>s <strong>W</strong>hat <strong>Y</strong>ou <strong>G</strong>et)</span></p>\r\n<h2>H2 Header</h2>\r\n<h3>H3 Header</h3>\r\n<h4>H4 Header</h4>\r\n<h5>H5 Header</h5>\r\n<h6>H6 Header</h6>\r\n<ol>\r\n    <li>Numeric List</li>\r\n    <li>Numeric List</li>\r\n    <li>Numeric List</li>\r\n</ol>\r\n<ul>\r\n    <li>This is a normal List</li>\r\n    <li>This is a normal List</li>\r\n    <li>This is a normal List</li>\r\n</ul>\r\n<blockquote>\r\n<p>Blockquote for writing important notes in your content<br />\r\nand style it different...</p>\r\n<p>&nbsp;</p>\r\n</blockquote>\r\n<p>&nbsp;<img width=\"115\" align=\"left\" height=\"167\" src=\"{SYSVAR:MEDIA_REL}/wb_box.png\" alt=\"\" /></p>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: right;\"><u><em><strong>Text right side</strong></em></u><br />\r\n[[Lorem?blocks=1]]</p>\r\n<p style=\"text-align: center;\"><u><em><strong>Text center</strong></em></u></p>\r\n<p style=\"text-align: center;\">[[Lorem?blocks=1]]</p>\r\n<pre>\r\nFor other special notes in your content ...</pre>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: left;\"><u><em><strong>Text left side</strong></em></u><br />\r\n[[Lorem?blocks=4]]</p>');
/*!40000 ALTER TABLE `wb_mod_wysiwyg` ENABLE KEYS */;


--
-- Create Table `wb_pages`
--

DROP TABLE IF EXISTS `wb_pages`;
CREATE TABLE `wb_pages` (
  `page_id` int(11) NOT NULL AUTO_INCREMENT,
  `parent` int(11) NOT NULL DEFAULT '0',
  `root_parent` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  `link` text COLLATE utf8_unicode_ci NOT NULL,
  `target` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `page_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `keywords` text COLLATE utf8_unicode_ci NOT NULL,
  `page_trail` text COLLATE utf8_unicode_ci NOT NULL,
  `template` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `visibility` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `position` int(11) NOT NULL DEFAULT '0',
  `menu` int(11) NOT NULL DEFAULT '0',
  `language` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `searching` int(11) NOT NULL DEFAULT '0',
  `admin_groups` text COLLATE utf8_unicode_ci NOT NULL,
  `admin_users` text COLLATE utf8_unicode_ci NOT NULL,
  `viewing_groups` text COLLATE utf8_unicode_ci NOT NULL,
  `viewing_users` text COLLATE utf8_unicode_ci NOT NULL,
  `modified_when` int(11) NOT NULL DEFAULT '0',
  `modified_by` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`page_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_pages`
--

/*!40000 ALTER TABLE `wb_pages` DISABLE KEYS */;
INSERT INTO `wb_pages` (`page_id`,`parent`,`root_parent`,`level`,`link`,`target`,`page_title`,`menu_title`,`description`,`keywords`,`page_trail`,`template`,`visibility`,`position`,`menu`,`language`,`searching`,`admin_groups`,`admin_users`,`viewing_groups`,`viewing_users`,`modified_when`,`modified_by`) VALUES ('1','0','0','0','/wysiwyg','_top','WYSIWYG','WYSIWYG','','','1','','public','1','1','EN','1','1','','1','','1329414701','1');
INSERT INTO `wb_pages` (`page_id`,`parent`,`root_parent`,`level`,`link`,`target`,`page_title`,`menu_title`,`description`,`keywords`,`page_trail`,`template`,`visibility`,`position`,`menu`,`language`,`searching`,`admin_groups`,`admin_users`,`viewing_groups`,`viewing_users`,`modified_when`,`modified_by`) VALUES ('2','0','0','0','/news-page','_top','NEWS Page','NEWS Page','','','2','','public','2','1','EN','1','1','','1','','1382799965','1');
INSERT INTO `wb_pages` (`page_id`,`parent`,`root_parent`,`level`,`link`,`target`,`page_title`,`menu_title`,`description`,`keywords`,`page_trail`,`template`,`visibility`,`position`,`menu`,`language`,`searching`,`admin_groups`,`admin_users`,`viewing_groups`,`viewing_users`,`modified_when`,`modified_by`) VALUES ('3','0','0','0','/form-page','_top','FORM Page','FORM Page','','','3','','public','3','1','EN','1','1','','1','','1444839781','1');
INSERT INTO `wb_pages` (`page_id`,`parent`,`root_parent`,`level`,`link`,`target`,`page_title`,`menu_title`,`description`,`keywords`,`page_trail`,`template`,`visibility`,`position`,`menu`,`language`,`searching`,`admin_groups`,`admin_users`,`viewing_groups`,`viewing_users`,`modified_when`,`modified_by`) VALUES ('4','0','0','0','/wrapper-page','_top','WRAPPER Page','WRAPPER Page','','','4','','public','4','1','EN','1','1','','1','','1329328889','1');
INSERT INTO `wb_pages` (`page_id`,`parent`,`root_parent`,`level`,`link`,`target`,`page_title`,`menu_title`,`description`,`keywords`,`page_trail`,`template`,`visibility`,`position`,`menu`,`language`,`searching`,`admin_groups`,`admin_users`,`viewing_groups`,`viewing_users`,`modified_when`,`modified_by`) VALUES ('5','0','0','0','/code-page','_top','CODE Page','CODE Page','','','5','','public','5','1','EN','1','1','','1','','1265703571','1');
INSERT INTO `wb_pages` (`page_id`,`parent`,`root_parent`,`level`,`link`,`target`,`page_title`,`menu_title`,`description`,`keywords`,`page_trail`,`template`,`visibility`,`position`,`menu`,`language`,`searching`,`admin_groups`,`admin_users`,`viewing_groups`,`viewing_users`,`modified_when`,`modified_by`) VALUES ('6','0','0','0','/external-link','_blank','EXTERNAL Link','EXTERNAL Link','','','6','','public','6','1','EN','1','1','','1','','1329414035','1');
/*!40000 ALTER TABLE `wb_pages` ENABLE KEYS */;


--
-- Create Table `wb_search`
--

DROP TABLE IF EXISTS `wb_search`;
CREATE TABLE `wb_search` (
  `search_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `extra` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`search_id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_search`
--

/*!40000 ALTER TABLE `wb_search` DISABLE KEYS */;
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('1','header','<h1>[TEXT_SEARCH]</h1>\r\n\r\n<form name=\"searchpage\" action=\"[WB_URL]/search/index.php\" method=\"get\">\r\n<table cellpadding=\"3\" cellspacing=\"0\" border=\"0\" width=\"500\">\r\n<tr>\r\n<td>\r\n<input type=\"hidden\" name=\"search_path\" value=\"[SEARCH_PATH]\" />\r\n<input type=\"text\" name=\"string\" value=\"[SEARCH_STRING]\" style=\"width: 100%;\" />\r\n</td>\r\n<td width=\"150\">\r\n<input type=\"submit\" value=\"[TEXT_SEARCH]\" style=\"width: 100%;\" />\r\n</td>\r\n</tr>\r\n<tr>\r\n<td colspan=\"2\">\r\n<input type=\"radio\" name=\"match\" id=\"match_all\" value=\"all\"[ALL_CHECKED] />\r\n<label for=\"match_all\">[TEXT_ALL_WORDS]</label>\r\n<input type=\"radio\" name=\"match\" id=\"match_any\" value=\"any\"[ANY_CHECKED] />\r\n<label for=\"match_any\">[TEXT_ANY_WORDS]</label>\r\n<input type=\"radio\" name=\"match\" id=\"match_exact\" value=\"exact\"[EXACT_CHECKED] />\r\n<label for=\"match_exact\">[TEXT_EXACT_MATCH]</label>\r\n</td>\r\n</tr>\r\n</table>\r\n\r\n</form>\r\n\r\n<hr />\r\n	','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('2','footer','','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('3','results_header','[TEXT_RESULTS_FOR] \'<b>[SEARCH_STRING]</b>\':\r\n<table cellpadding=\"2\" cellspacing=\"0\" border=\"0\" width=\"100%\" style=\"padding-top: 10px;\">','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('4','results_loop','<tr style=\"background-color: #F0F0F0;\">\r\n<td><a href=\"[LINK]\">[TITLE]</a></td>\r\n<td align=\"right\">[TEXT_LAST_UPDATED_BY] [DISPLAY_NAME] ([USERNAME]) [TEXT_ON] [DATE]</td>\r\n</tr>\r\n<tr><td colspan=\"2\" style=\"text-align: justify; padding-bottom: 5px;\">[DESCRIPTION]</td></tr>\r\n<tr><td colspan=\"2\" style=\"text-align: justify; padding-bottom: 10px;\">[EXCERPT]</td></tr>','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('5','results_footer','</table>','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('6','no_results','<tr><td><p>[TEXT_NO_RESULTS]</p></td></tr>','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('7','module_order','faqbaker,manual,wysiwyg','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('8','max_excerpt','15','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('9','time_limit','0','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('10','cfg_enable_old_search','true','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('11','cfg_search_keywords','true','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('12','cfg_search_description','true','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('13','cfg_show_description','true','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('14','cfg_enable_flush','false','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('15','template','','');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('16','module','code','a:6:{s:7:\"page_id\";s:7:\"page_id\";s:5:\"title\";s:10:\"page_title\";s:4:\"link\";s:4:\"link\";s:11:\"description\";s:11:\"description\";s:13:\"modified_when\";s:13:\"modified_when\";s:11:\"modified_by\";s:11:\"modified_by\";}');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('17','query_start','SELECT [TP]pages.page_id, [TP]pages.page_title,	[TP]pages.link, [TP]pages.description, [TP]pages.modified_when, [TP]pages.modified_by	FROM [TP]mod_code, [TP]pages WHERE ','code');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('18','query_body',' [TP]pages.page_id = [TP]mod_code.page_id AND [TP]mod_code.content [O] \'[W][STRING][W]\' AND [TP]pages.searching = \'1\'','code');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('19','query_end','','code');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('20','module','form','a:6:{s:7:\"page_id\";s:7:\"page_id\";s:5:\"title\";s:10:\"page_title\";s:4:\"link\";s:4:\"link\";s:11:\"description\";s:11:\"description\";s:13:\"modified_when\";s:13:\"modified_when\";s:11:\"modified_by\";s:11:\"modified_by\";}');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('21','query_start','SELECT [TP]pages.page_id, [TP]pages.page_title,	[TP]pages.link, [TP]pages.description, [TP]pages.modified_when, [TP]pages.modified_by	FROM [TP]mod_form_fields, [TP]mod_form_settings, [TP]pages WHERE ','form');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('22','query_body',' [TP]pages.page_id = [TP]mod_form_settings.page_id AND [TP]mod_form_settings.header LIKE \'%[STRING]%\'\n    	OR [TP]pages.page_id = [TP]mod_form_settings.page_id AND [TP]mod_form_settings.footer LIKE \'%[STRING]%\'\n    	OR [TP]pages.page_id = [TP]mod_form_fields.page_id AND [TP]mod_form_fields.title LIKE \'%[STRING]%\' ','form');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('23','query_end','','form');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('24','module','form','a:6:{s:7:\"page_id\";s:7:\"page_id\";s:5:\"title\";s:10:\"page_title\";s:4:\"link\";s:4:\"link\";s:11:\"description\";s:11:\"description\";s:13:\"modified_when\";s:13:\"modified_when\";s:11:\"modified_by\";s:11:\"modified_by\";}');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('25','query_start','SELECT [TP]pages.page_id, [TP]pages.page_title,	[TP]pages.link, [TP]pages.description, [TP]pages.modified_when, [TP]pages.modified_by	FROM [TP]mod_form_fields, [TP]mod_form_settings, [TP]pages WHERE ','form');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('26','query_body',' [TP]pages.page_id = [TP]mod_form_settings.page_id AND [TP]mod_form_settings.header LIKE \'%[STRING]%\'\r\n    	OR [TP]pages.page_id = [TP]mod_form_settings.page_id AND [TP]mod_form_settings.footer LIKE \'%[STRING]%\'\r\n    	OR [TP]pages.page_id = [TP]mod_form_fields.page_id AND [TP]mod_form_fields.title LIKE \'%[STRING]%\' ','form');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('27','query_end','','form');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('28','module','code','a:6:{s:7:\"page_id\";s:7:\"page_id\";s:5:\"title\";s:10:\"page_title\";s:4:\"link\";s:4:\"link\";s:11:\"description\";s:11:\"description\";s:13:\"modified_when\";s:13:\"modified_when\";s:11:\"modified_by\";s:11:\"modified_by\";}');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('29','query_start','SELECT [TP]pages.page_id, [TP]pages.page_title,	[TP]pages.link, [TP]pages.description, [TP]pages.modified_when, [TP]pages.modified_by	FROM [TP]mod_code, [TP]pages WHERE ','code');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('30','query_body',' [TP]pages.page_id = [TP]mod_code.page_id AND [TP]mod_code.content [O] \'[W][STRING][W]\' AND [TP]pages.searching = \'1\'','code');
INSERT INTO `wb_search` (`search_id`,`name`,`value`,`extra`) VALUES ('31','query_end','','code');
/*!40000 ALTER TABLE `wb_search` ENABLE KEYS */;


--
-- Create Table `wb_sections`
--

DROP TABLE IF EXISTS `wb_sections`;
CREATE TABLE `wb_sections` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `module` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `block` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `publ_start` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `publ_end` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`section_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_sections`
--

/*!40000 ALTER TABLE `wb_sections` DISABLE KEYS */;
INSERT INTO `wb_sections` (`section_id`,`page_id`,`position`,`module`,`block`,`publ_start`,`publ_end`) VALUES ('7','2','1','wysiwyg','1','0','0');
INSERT INTO `wb_sections` (`section_id`,`page_id`,`position`,`module`,`block`,`publ_start`,`publ_end`) VALUES ('1','1','1','wysiwyg','1','0','0');
INSERT INTO `wb_sections` (`section_id`,`page_id`,`position`,`module`,`block`,`publ_start`,`publ_end`) VALUES ('3','3','1','form','1','0','0');
INSERT INTO `wb_sections` (`section_id`,`page_id`,`position`,`module`,`block`,`publ_start`,`publ_end`) VALUES ('4','4','1','wrapper','1','0','0');
INSERT INTO `wb_sections` (`section_id`,`page_id`,`position`,`module`,`block`,`publ_start`,`publ_end`) VALUES ('5','5','1','code','1','0','0');
INSERT INTO `wb_sections` (`section_id`,`page_id`,`position`,`module`,`block`,`publ_start`,`publ_end`) VALUES ('2','2','2','news','1','0','0');
INSERT INTO `wb_sections` (`section_id`,`page_id`,`position`,`module`,`block`,`publ_start`,`publ_end`) VALUES ('8','6','1','menu_link','1','0','0');
/*!40000 ALTER TABLE `wb_sections` ENABLE KEYS */;


--
-- Create Table `wb_settings`
--

DROP TABLE IF EXISTS `wb_settings`;
CREATE TABLE `wb_settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`setting_id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_settings`
--

/*!40000 ALTER TABLE `wb_settings` DISABLE KEYS */;
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('1','wb_version','2.8.3');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('2','wb_revision','1642');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('3','wb_sp','SP5');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('4','website_title','WebsiteBaker Portable -Edition- 2.8.3');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('5','website_description','');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('6','website_keywords','');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('7','website_header','');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('8','website_footer','');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('9','wysiwyg_style','font-family: Verdana, Arial, Helvetica, sans-serif; font-size: 12px;');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('10','er_level','0');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('11','default_language','EN');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('12','app_name','wb_1615');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('13','sec_anchor','wb_');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('14','default_timezone','0');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('15','default_date_format','m-d-Y');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('16','default_time_format','g:i a');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('17','redirect_timer','500');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('18','home_folders','true');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('19','warn_page_leave','1');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('20','default_template','pinzsimple');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('21','default_theme','wb_theme');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('22','default_charset','utf-8');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('23','multiple_menus','true');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('24','page_level_limit','4');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('25','intro_page','false');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('26','page_trash','inline');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('27','homepage_redirection','false');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('28','page_languages','true');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('29','wysiwyg_editor','fckeditor');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('30','manage_sections','true');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('31','section_blocks','true');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('32','smart_login','false');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('33','frontend_login','false');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('34','frontend_signup','false');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('35','search','public');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('36','page_extension','.php');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('37','page_spacer','-');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('38','pages_directory','/pages');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('39','rename_files_on_upload','ph.*?,cgi,pl,pm,exe,com,bat,pif,cmd,src,asp,aspx,js');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('40','media_directory','/media');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('41','operating_system','linux');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('42','string_file_mode','0644');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('43','string_dir_mode','0755');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('44','wbmailer_routine','phpmail');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('45','server_email','admin@yourdomain.de');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('46','wbmailer_default_sendername','WB Mailer');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('47','wbmailer_smtp_host','');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('48','wbmailer_smtp_auth','1');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('49','wbmailer_smtp_username','');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('50','wbmailer_smtp_password','');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('51','fingerprint_with_ip_octets','2');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('52','secure_form_module','');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('53','mediasettings','');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('54','wb_secform_secret','5609bnefg93jmgi99igjefg');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('55','wb_secform_secrettime','86400');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('56','wb_secform_timeout','7200');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('57','wb_secform_tokenname','formtoken');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('58','wb_secform_usefp','true');
INSERT INTO `wb_settings` (`setting_id`,`name`,`value`) VALUES ('59','wb_secform_useip','2');
/*!40000 ALTER TABLE `wb_settings` ENABLE KEYS */;


--
-- Create Table `wb_users`
--

DROP TABLE IF EXISTS `wb_users`;
CREATE TABLE `wb_users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `remember_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `last_reset` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `timezone` int(11) NOT NULL DEFAULT '0',
  `date_format` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `time_format` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `language` varchar(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'EN',
  `home_folder` text COLLATE utf8_unicode_ci NOT NULL,
  `login_when` int(11) NOT NULL DEFAULT '0',
  `login_ip` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Data for Table `wb_users`
--

/*!40000 ALTER TABLE `wb_users` DISABLE KEYS */;
INSERT INTO `wb_users` (`user_id`,`group_id`,`groups_id`,`active`,`username`,`password`,`remember_key`,`last_reset`,`display_name`,`email`,`timezone`,`date_format`,`time_format`,`language`,`home_folder`,`login_when`,`login_ip`) VALUES ('1','1','1','1','admin','21232f297a57a5a743894a0e4a801fc3','','0','Administrator','admin@yourdomain.de','-72000','','','EN','','1444886759','127.0.0.1');
/*!40000 ALTER TABLE `wb_users` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

